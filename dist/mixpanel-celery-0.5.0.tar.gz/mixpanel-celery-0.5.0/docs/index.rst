Welcome to mixpanel-celery's documentation!
===========================================

Contents:

.. toctree::
   :maxdepth: 2

   introduction
   configuration
   reference/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`