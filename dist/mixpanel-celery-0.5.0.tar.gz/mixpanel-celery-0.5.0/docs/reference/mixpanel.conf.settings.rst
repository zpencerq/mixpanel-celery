================================================
Configuration: mixpanel - mixpanel.conf.settings
================================================

.. currentmodule:: mixpanel.conf.settings

.. automodule:: mixpanel.conf.settings
    :members: