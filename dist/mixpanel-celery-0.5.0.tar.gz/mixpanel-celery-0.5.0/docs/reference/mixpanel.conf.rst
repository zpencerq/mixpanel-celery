===========================================
Mixpanel Settings: mixpanel - mixpanel.conf
===========================================

.. currentmodule:: mixpanel.conf

.. automodule:: mixpanel.conf
    :members: